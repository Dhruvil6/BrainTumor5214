export default function Nav() {
    return (
        <div className="w-full bg-[#036fc4]">
            <div className="flex-center">
                <h1 className="text-[100px] text-white">Brain Tumor Scan</h1>
            </div>
        </div>
    );
}
